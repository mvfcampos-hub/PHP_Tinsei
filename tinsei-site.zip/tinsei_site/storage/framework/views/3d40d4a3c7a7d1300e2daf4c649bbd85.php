<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $globalNoticeBanners ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-gold-400 text-brand-950">
        <div class="container-site flex flex-wrap items-center justify-center gap-x-3 gap-y-1 py-2 text-center text-sm">
            <span class="font-semibold"><?php echo e($notice->title); ?></span>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($notice->subtitle): ?>
                <span class="hidden sm:inline text-brand-900/80"><?php echo e($notice->subtitle); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($notice->link_url): ?>
                <a href="<?php echo e($notice->link_url); ?>" class="inline-flex items-center gap-1 font-semibold underline underline-offset-2 hover:no-underline">
                    <?php echo e($notice->link_label ?: 'Saiba mais'); ?> →
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /home/claude/pkg/tinsei_site/resources/views/partials/notice-banner.blade.php ENDPATH**/ ?>