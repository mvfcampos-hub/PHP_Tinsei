<footer class="relative overflow-hidden bg-brand-950 text-brand-200">
    <div class="absolute inset-0 bg-grid-pattern bg-grid opacity-60"></div>
    <img src="<?php echo e(asset('images/brand/tinsei-mark.png')); ?>" alt="" class="pointer-events-none absolute -bottom-20 -left-10 h-80 opacity-[0.04]">

    
    <div class="relative border-b border-white/10">
        <div class="container-site flex flex-col items-start justify-between gap-6 py-10 md:flex-row md:items-center">
            <div>
                <p class="font-display text-2xl font-bold text-white"><?php echo e(setting('portfolio_items')); ?> itens prontos para a sua revenda.</p>
                <p class="mt-1 text-brand-200">Equipamentos novos e recondicionados, suprimentos e peças — consulte preços e disponibilidade na loja.</p>
            </div>
            <div class="flex shrink-0 flex-wrap gap-3">
                <a href="<?php echo e(setting('store_url')); ?>" target="_blank" rel="noopener" class="btn-gold" onclick="window.trackEvent && window.trackEvent('store_click', { location: 'footer' })">
                    <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'grid','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grid','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?> Acessar o portfólio
                </a>
                <a href="<?php echo e(setting('store_reseller_url')); ?>" target="_blank" rel="noopener" class="btn-ghost-light">Cadastre sua revenda</a>
            </div>
        </div>
    </div>

    <div class="container-site relative grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-12">
        <div class="lg:col-span-4">
            <?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['variant' => 'white','class' => 'h-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'white','class' => 'h-12']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
            <p class="mt-5 max-w-sm text-sm leading-relaxed">
                Importação, recondicionamento e distribuição de equipamentos de impressão, suprimentos e peças — com qualidade, confiança, preço competitivo e sustentabilidade no DNA.
            </p>
            <?php if (isset($component)) { $__componentOriginal624d54d54bd3bad8c2fe62c4add9ad06 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal624d54d54bd3bad8c2fe62c4add9ad06 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.social-links','data' => ['class' => 'mt-6 gap-4 text-white','iconClass' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('social-links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-6 gap-4 text-white','icon-class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal624d54d54bd3bad8c2fe62c4add9ad06)): ?>
<?php $attributes = $__attributesOriginal624d54d54bd3bad8c2fe62c4add9ad06; ?>
<?php unset($__attributesOriginal624d54d54bd3bad8c2fe62c4add9ad06); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal624d54d54bd3bad8c2fe62c4add9ad06)): ?>
<?php $component = $__componentOriginal624d54d54bd3bad8c2fe62c4add9ad06; ?>
<?php unset($__componentOriginal624d54d54bd3bad8c2fe62c4add9ad06); ?>
<?php endif; ?>
        </div>

        <div class="lg:col-span-2">
            <p class="text-sm font-semibold text-white">A Tinsei</p>
            <ul class="mt-4 space-y-2.5 text-sm">
                <li><a href="<?php echo e(route('about')); ?>" class="hover:text-white">Quem somos</a></li>
                <li><a href="<?php echo e(route('about')); ?>#historia" class="hover:text-white">Nossa história</a></li>
                <li><a href="<?php echo e(route('about')); ?>#socios" class="hover:text-white">Sócios</a></li>
                <li><a href="<?php echo e(route('sustainability')); ?>" class="hover:text-white">Sustentabilidade</a></li>
                <li><a href="<?php echo e(route('careers.index')); ?>" class="hover:text-white">Trabalhe conosco</a></li>
            </ul>
        </div>

        <div class="lg:col-span-2">
            <p class="text-sm font-semibold text-white">Conteúdo</p>
            <ul class="mt-4 space-y-2.5 text-sm">
                <li><a href="<?php echo e(route('portfolio')); ?>" class="hover:text-white">Portfólio</a></li>
                <li><a href="<?php echo e(route('news.index')); ?>" class="hover:text-white">Notícias</a></li>
                <li><a href="<?php echo e(route('events.index')); ?>" class="hover:text-white">Agenda</a></li>
                <li><a href="<?php echo e(route('testimonials')); ?>" class="hover:text-white">Depoimentos</a></li>
                <li><a href="<?php echo e(route('presence')); ?>" class="hover:text-white">Onde estamos</a></li>
            </ul>
        </div>

        <div class="sm:col-span-2 lg:col-span-4">
            <p class="text-sm font-semibold text-white">Fale com a Tinsei</p>
            <ul class="mt-4 space-y-3 text-sm">
                <li class="flex gap-3"><?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'pin','class' => 'h-5 w-5 shrink-0 text-gold-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pin','class' => 'h-5 w-5 shrink-0 text-gold-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?><span class="whitespace-pre-line"><?php echo e(setting('address')); ?></span></li>
                <li class="flex gap-3"><?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'phone','class' => 'h-5 w-5 shrink-0 text-gold-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone','class' => 'h-5 w-5 shrink-0 text-gold-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?><a href="tel:<?php echo e(preg_replace('/\D/', '', setting('phone'))); ?>" class="hover:text-white"><?php echo e(setting('phone')); ?></a></li>
                <li class="flex gap-3"><?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'mail','class' => 'h-5 w-5 shrink-0 text-gold-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'mail','class' => 'h-5 w-5 shrink-0 text-gold-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?><a href="mailto:<?php echo e(setting('email')); ?>" class="hover:text-white"><?php echo e(setting('email')); ?></a></li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(setting('business_hours')): ?>
                    <li class="flex gap-3"><?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'clock','class' => 'h-5 w-5 shrink-0 text-gold-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'clock','class' => 'h-5 w-5 shrink-0 text-gold-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?><?php echo e(setting('business_hours')); ?></li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
            <a href="<?php echo e(route('contact.index')); ?>" class="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-gold-300 hover:text-gold-200">Enviar uma mensagem <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'arrow-right','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?></a>
        </div>
    </div>

    <div class="relative border-t border-white/10">
        <div class="container-site flex flex-col gap-3 py-6 text-xs text-brand-300 md:flex-row md:items-center md:justify-between">
            <p>© <?php echo e(now()->year); ?> <?php echo e(setting('legal_name')); ?> · CNPJ <?php echo e(setting('cnpj')); ?></p>
            <div class="flex flex-wrap gap-x-5 gap-y-2">
                <a href="<?php echo e(route('pages.show', 'politica-de-privacidade')); ?>" class="hover:text-white">Política de Privacidade</a>
                <a href="<?php echo e(route('pages.show', 'termos-de-uso')); ?>" class="hover:text-white">Termos de Uso</a>
                <a href="<?php echo e(route('sitemap')); ?>" class="hover:text-white">Mapa do site</a>
                <span>Desenvolvido por <a href="https://www.databit.com.br/" target="_blank" rel="noopener" class="font-semibold text-brand-100 hover:text-white">Databit</a></span>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/claude/pkg/tinsei_site/resources/views/partials/footer.blade.php ENDPATH**/ ?>