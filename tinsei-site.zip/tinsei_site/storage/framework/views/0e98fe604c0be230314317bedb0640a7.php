<div class="hidden md:block bg-brand-950 text-brand-200 text-xs">
    <div class="container-site flex h-9 items-center justify-between gap-6">
        <div class="flex items-center gap-5">
            <a href="tel:<?php echo e(preg_replace('/\D/', '', setting('phone'))); ?>" class="inline-flex items-center gap-1.5 hover:text-white transition">
                <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'phone','class' => 'h-3.5 w-3.5 text-gold-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone','class' => 'h-3.5 w-3.5 text-gold-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?> <?php echo e(setting('phone')); ?>

            </a>
            <a href="mailto:<?php echo e(setting('email')); ?>" class="inline-flex items-center gap-1.5 hover:text-white transition">
                <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'mail','class' => 'h-3.5 w-3.5 text-gold-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'mail','class' => 'h-3.5 w-3.5 text-gold-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?> <?php echo e(setting('email')); ?>

            </a>
            <span class="hidden lg:inline-flex items-center gap-1.5">
                <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'pin','class' => 'h-3.5 w-3.5 text-gold-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pin','class' => 'h-3.5 w-3.5 text-gold-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?> Belo Horizonte · MG — atendemos todo o Brasil
            </span>
        </div>
        <div class="flex items-center gap-4">
            <a href="<?php echo e(setting('store_reseller_url')); ?>" target="_blank" rel="noopener" class="font-semibold text-gold-300 hover:text-gold-200 transition">Seja uma revenda</a>
            <span class="h-3 w-px bg-white/15"></span>
            <?php if (isset($component)) { $__componentOriginal624d54d54bd3bad8c2fe62c4add9ad06 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal624d54d54bd3bad8c2fe62c4add9ad06 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.social-links','data' => ['class' => 'gap-3','iconClass' => 'h-3.5 w-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('social-links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'gap-3','icon-class' => 'h-3.5 w-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal624d54d54bd3bad8c2fe62c4add9ad06)): ?>
<?php $attributes = $__attributesOriginal624d54d54bd3bad8c2fe62c4add9ad06; ?>
<?php unset($__attributesOriginal624d54d54bd3bad8c2fe62c4add9ad06); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal624d54d54bd3bad8c2fe62c4add9ad06)): ?>
<?php $component = $__componentOriginal624d54d54bd3bad8c2fe62c4add9ad06; ?>
<?php unset($__componentOriginal624d54d54bd3bad8c2fe62c4add9ad06); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /home/claude/pkg/tinsei_site/resources/views/partials/topbar.blade.php ENDPATH**/ ?>