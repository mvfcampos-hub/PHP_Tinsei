<?php
    $storeUrl = setting('store_url');
    $isActive = fn (string $url) => $url !== '#' && (request()->url() === $url || (strlen($url) > strlen(url('/')) && str_starts_with(request()->url(), rtrim($url, '/'))));
?>
<header
    x-data="{ mobileOpen: false, searchOpen: false, scrolled: false }"
    x-init="scrolled = window.scrollY > 10"
    @scroll.window="scrolled = window.scrollY > 10"
    @keydown.escape.window="searchOpen = false; mobileOpen = false"
    :class="scrolled ? 'shadow-soft bg-white/95' : 'bg-white'"
    class="sticky top-0 z-40 border-b border-slate-200/70 backdrop-blur transition"
>
    <div class="container-site">
        <div class="flex h-[72px] items-center justify-between gap-6">
            <a href="<?php echo e(route('home')); ?>" class="shrink-0" aria-label="Tinsei — página inicial">
                <?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['class' => 'h-11']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-11']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
            </a>

            <nav class="hidden lg:flex items-center gap-1" aria-label="Menu principal">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $mainMenu ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->is_highlighted) continue; ?>
                    <?php $url = $item->resolveUrl(); ?>
                    <div class="relative group">
                        <a
                            href="<?php echo e($url); ?>"
                            <?php if($item->opens_new_tab): ?> target="_blank" rel="noopener" <?php endif; ?>
                            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-semibold transition',
                                'text-brand-800 bg-brand-50' => $isActive($url),
                                'text-slate-600 hover:text-brand-800 hover:bg-slate-50' => ! $isActive($url),
                            ]); ?>"
                        >
                            <?php echo e($item->label); ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->children->isNotEmpty()): ?>
                                <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'chevron-down','class' => 'h-3.5 w-3.5 text-slate-400 transition group-hover:rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','class' => 'h-3.5 w-3.5 text-slate-400 transition group-hover:rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </a>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->children->isNotEmpty()): ?>
                            <div class="invisible absolute left-0 top-full z-50 w-60 translate-y-1 pt-2 opacity-0 transition group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                                <div class="rounded-2xl border border-slate-200 bg-white p-2 shadow-soft">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e($child->resolveUrl()); ?>" <?php if($child->opens_new_tab): ?> target="_blank" rel="noopener" <?php endif; ?> class="block rounded-xl px-3 py-2 text-sm font-medium text-slate-600 hover:bg-brand-50 hover:text-brand-800">
                                            <?php echo e($child->label); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </nav>

            <div class="flex items-center gap-2">
                <button type="button" @click="searchOpen = !searchOpen; $nextTick(() => $refs.searchInput?.focus())" class="hidden sm:flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 hover:text-brand-800 transition" aria-label="Buscar no site">
                    <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'search','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
                </button>
                <a href="<?php echo e($storeUrl); ?>" target="_blank" rel="noopener" class="btn-gold !py-2.5 hidden sm:inline-flex" onclick="window.trackEvent && window.trackEvent('store_click', { location: 'header' })">
                    <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'grid','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grid','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
                    Portfólio de produtos
                </a>
                <button type="button" @click="mobileOpen = !mobileOpen" class="lg:hidden flex h-10 w-10 items-center justify-center rounded-xl text-brand-800 hover:bg-slate-100" :aria-expanded="mobileOpen" aria-label="Abrir menu">
                    <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'menu','class' => 'h-6 w-6','xShow' => '!mobileOpen']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu','class' => 'h-6 w-6','x-show' => '!mobileOpen']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'x','class' => 'h-6 w-6','xShow' => 'mobileOpen','xCloak' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x','class' => 'h-6 w-6','x-show' => 'mobileOpen','x-cloak' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
                </button>
            </div>
        </div>
    </div>

    
    <div x-show="searchOpen" x-cloak x-transition.opacity class="border-t border-slate-200 bg-white">
        <form action="<?php echo e(route('search')); ?>" method="GET" class="container-site flex items-center gap-3 py-4">
            <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'search','class' => 'h-5 w-5 text-slate-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','class' => 'h-5 w-5 text-slate-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
            <input x-ref="searchInput" type="search" name="q" placeholder="Buscar notícias, eventos e páginas..." class="flex-1 border-0 bg-transparent text-base focus:ring-0 focus:outline-none" aria-label="Termo de busca">
            <a href="<?php echo e($storeUrl); ?>" target="_blank" rel="noopener" class="hidden md:inline text-xs font-semibold text-brand-700 hover:underline">Procurando um produto? Busque na loja →</a>
        </form>
    </div>

    
    <div x-show="mobileOpen" x-cloak x-transition class="lg:hidden border-t border-slate-200 bg-white">
        <nav class="container-site py-4 space-y-1" aria-label="Menu principal (celular)">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $mainMenu ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->is_highlighted) continue; ?>
                <a href="<?php echo e($item->resolveUrl()); ?>" class="block rounded-xl px-3 py-2.5 text-base font-semibold text-slate-700 hover:bg-brand-50"><?php echo e($item->label); ?></a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($child->resolveUrl()); ?>" class="block rounded-xl pl-7 pr-3 py-2 text-sm text-slate-500 hover:bg-brand-50"><?php echo e($child->label); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <form action="<?php echo e(route('search')); ?>" method="GET" class="pt-2">
                <input type="search" name="q" placeholder="Buscar no site..." class="form-input" aria-label="Buscar no site">
            </form>
            <a href="<?php echo e($storeUrl); ?>" target="_blank" rel="noopener" class="btn-gold w-full mt-3">
                <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'grid','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grid','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?> Portfólio de produtos
            </a>
            <a href="<?php echo e(setting('store_reseller_url')); ?>" target="_blank" rel="noopener" class="btn-outline w-full">Seja uma revenda</a>
        </nav>
    </div>
</header>
<?php /**PATH /home/claude/pkg/tinsei_site/resources/views/partials/header.blade.php ENDPATH**/ ?>