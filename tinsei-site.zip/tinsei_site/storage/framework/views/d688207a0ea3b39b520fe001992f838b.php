<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['news']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['news']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<article class="group card flex flex-col overflow-hidden transition hover:-translate-y-1 hover:shadow-soft">
    <a href="<?php echo e(route('news.show', $news->slug)); ?>" class="relative block aspect-[16/9] overflow-hidden bg-brand-100">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cover = $news->coverUrl()): ?>
            <img src="<?php echo e($cover); ?>" alt="" loading="lazy" class="h-full w-full object-cover transition duration-500 group-hover:scale-105">
        <?php else: ?>
            <div class="flex h-full w-full items-center justify-center bg-gradient-to-br from-brand-800 to-brand-600">
                <img src="<?php echo e(asset('images/brand/tinsei-mark.png')); ?>" alt="" class="h-14 opacity-80">
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($news->youtubeId()): ?>
            <span class="absolute inset-0 flex items-center justify-center">
                <span class="flex h-12 w-12 items-center justify-center rounded-full bg-white/90 text-brand-800 shadow-lg"><?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'play','class' => 'h-5 w-5 translate-x-0.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'play','class' => 'h-5 w-5 translate-x-0.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?></span>
            </span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($news->category): ?>
            <span class="absolute left-3 top-3 rounded-full bg-white/95 px-2.5 py-1 text-[11px] font-semibold text-brand-800"><?php echo e($news->category); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </a>
    <div class="flex flex-1 flex-col p-5">
        <time datetime="<?php echo e($news->published_at?->toDateString()); ?>" class="text-xs font-medium text-slate-400"><?php echo e($news->published_at?->translatedFormat('d \d\e F \d\e Y')); ?></time>
        <h3 class="mt-2 text-lg font-semibold leading-snug text-brand-900 group-hover:text-brand-600">
            <a href="<?php echo e(route('news.show', $news->slug)); ?>"><?php echo e($news->title); ?></a>
        </h3>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($news->excerpt): ?>
            <p class="mt-2 line-clamp-3 text-sm leading-relaxed text-slate-500"><?php echo e($news->excerpt); ?></p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <a href="<?php echo e(route('news.show', $news->slug)); ?>" class="mt-auto pt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-700 group-hover:gap-2 transition-all">
            Ler mais <?php if (isset($component)) { $__componentOriginala231aa52073ee357093dd0e300d7d061 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala231aa52073ee357093dd0e300d7d061 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ico','data' => ['name' => 'arrow-right','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ico'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $attributes = $__attributesOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__attributesOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala231aa52073ee357093dd0e300d7d061)): ?>
<?php $component = $__componentOriginala231aa52073ee357093dd0e300d7d061; ?>
<?php unset($__componentOriginala231aa52073ee357093dd0e300d7d061); ?>
<?php endif; ?>
        </a>
    </div>
</article>
<?php /**PATH /home/claude/pkg/tinsei_site/resources/views/components/news-card.blade.php ENDPATH**/ ?>