<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['eyebrow' => null, 'title', 'subtitle' => null, 'image' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['eyebrow' => null, 'title', 'subtitle' => null, 'image' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<section class="relative overflow-hidden bg-brand-900 bg-grid-pattern bg-grid">
    <div class="absolute inset-0 bg-gradient-to-br from-brand-950 via-brand-900/95 to-brand-800/80"></div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($image): ?>
        <img src="<?php echo e($image); ?>" alt="" class="absolute inset-y-0 right-0 hidden h-full w-1/2 object-cover opacity-25 lg:block [mask-image:linear-gradient(to_left,black,transparent)]">
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <img src="<?php echo e(asset('images/brand/tinsei-mark.png')); ?>" alt="" class="pointer-events-none absolute -right-10 -bottom-16 h-72 w-auto opacity-[0.06]">
    <div class="container-site relative py-16 sm:py-20">
        <nav class="mb-6 text-xs text-brand-300" aria-label="Você está em">
            <a href="<?php echo e(route('home')); ?>" class="hover:text-white">Início</a>
            <span class="mx-1.5 text-brand-500">/</span>
            <span class="text-brand-100"><?php echo e($title); ?></span>
        </nav>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($eyebrow): ?>
            <span class="eyebrow eyebrow-light"><?php echo e($eyebrow); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <h1 class="mt-3 max-w-3xl text-4xl font-bold text-white sm:text-5xl"><?php echo e($title); ?></h1>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($subtitle): ?>
            <p class="mt-5 max-w-2xl text-lg leading-relaxed text-brand-100/90"><?php echo e($subtitle); ?></p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo e($slot); ?>

    </div>
</section>
<?php /**PATH /home/claude/pkg/tinsei_site/resources/views/components/page-hero.blade.php ENDPATH**/ ?>