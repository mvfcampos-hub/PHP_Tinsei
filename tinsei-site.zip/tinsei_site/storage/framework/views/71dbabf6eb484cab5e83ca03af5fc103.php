<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['map', 'dark' => true, 'showRanking' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['map', 'dark' => true, 'showRanking' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    use App\Support\ClientMap;
    $counts = $map['counts'];
    $max = $map['max'];
    $top = collect($map['ranking'])->take(8);
?>
<div
    x-data="{ hovered: null }"
    <?php echo e($attributes->merge(['class' => 'grid items-start gap-8 lg:grid-cols-5'])); ?>

>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['relative rounded-3xl p-4 sm:p-6 lg:col-span-3', 'border border-white/10 bg-white/[0.04]' => $dark, 'card' => ! $dark]); ?>">
        <div class="mb-2 flex min-h-[44px] items-start justify-between gap-4">
            <div>
                <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-sm font-semibold', 'text-white' => $dark, 'text-brand-900' => ! $dark]); ?>" x-show="!hovered">Passe o mouse (ou toque) em um estado</p>
                <p x-show="hovered" x-cloak class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-sm font-semibold', 'text-white' => $dark, 'text-brand-900' => ! $dark]); ?>">
                    <span x-text="hovered?.name"></span>
                    <span class="ml-1 font-display text-lg text-gold-400" x-text="hovered ? hovered.count.toLocaleString('pt-BR') : ''"></span>
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-xs font-normal', 'text-brand-200' => $dark, 'text-slate-500' => ! $dark]); ?>"> clientes ativos</span>
                </p>
            </div>
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex items-center gap-2 text-[11px]', 'text-brand-200' => $dark, 'text-slate-500' => ! $dark]); ?>">
                <span>menos</span>
                <span class="h-2 w-20 rounded-full bg-gradient-to-r from-brand-400/20 to-brand-300"></span>
                <span>mais</span>
            </div>
        </div>

        <svg viewBox="<?php echo e($map['svg']['view_box']); ?>" class="mx-auto h-auto max-h-[520px] w-full" role="img" aria-label="Mapa do Brasil com a quantidade de clientes ativos da Tinsei por estado">
            <defs>
                <filter id="map-glow" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="4" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
                </filter>
            </defs>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $map['svg']['states']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $count = (int) ($counts[$state['code']] ?? 0);
                    $alpha = ClientMap::intensity($count, $max);
                    $base = $count > 0 ? "rgba(140, 190, 219, {$alpha})" : ($dark ? 'rgba(255,255,255,0.04)' : 'rgba(0,59,90,0.06)');
                    $stroke = $dark ? '#012c44' : '#ffffff';
                ?>
                <path
                    d="<?php echo e($state['d']); ?>"
                    tabindex="0"
                    style="fill: <?php echo e($base); ?>; stroke: <?php echo e($stroke); ?>; stroke-width: 1.2; transition: fill .15s, filter .15s; outline: none;"
                    :style="hovered && hovered.code === '<?php echo e($state['code']); ?>' ? 'fill: #e8b042; stroke: #fff; stroke-width: 1.6; filter: url(#map-glow); outline: none;' : 'fill: <?php echo e($base); ?>; stroke: <?php echo e($stroke); ?>; stroke-width: 1.2; outline: none;'"
                    class="cursor-pointer"
                    @mouseenter="hovered = { code: '<?php echo e($state['code']); ?>', name: <?php echo \Illuminate\Support\Js::from($state['name'])->toHtml() ?>, count: <?php echo e($count); ?> }"
                    @focus="hovered = { code: '<?php echo e($state['code']); ?>', name: <?php echo \Illuminate\Support\Js::from($state['name'])->toHtml() ?>, count: <?php echo e($count); ?> }"
                    @click="hovered = { code: '<?php echo e($state['code']); ?>', name: <?php echo \Illuminate\Support\Js::from($state['name'])->toHtml() ?>, count: <?php echo e($count); ?> }"
                    @mouseleave="hovered = null"
                    @blur="hovered = null"
                ><title><?php echo e($state['name']); ?>: <?php echo e(br_number($count)); ?> clientes ativos</title></path>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </svg>
        <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-2 text-right text-[10px]', 'text-brand-400' => $dark, 'text-slate-400' => ! $dark]); ?>">Base do mapa: svg-maps.com (CC BY 4.0)</p>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showRanking): ?>
        <div class="space-y-5 lg:col-span-2">
            <div class="grid grid-cols-3 gap-3">
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['rounded-2xl p-4', 'bg-white/[0.06] border border-white/10' => $dark, 'card' => ! $dark]); ?>">
                    <p class="font-display text-2xl font-bold text-gold-400"><?php echo e(br_number($map['total'])); ?></p>
                    <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-1 text-[11px] leading-tight', 'text-brand-200' => $dark, 'text-slate-500' => ! $dark]); ?>">clientes ativos</p>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['rounded-2xl p-4', 'bg-white/[0.06] border border-white/10' => $dark, 'card' => ! $dark]); ?>">
                    <p class="font-display text-2xl font-bold text-gold-400"><?php echo e($map['states_served']); ?></p>
                    <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-1 text-[11px] leading-tight', 'text-brand-200' => $dark, 'text-slate-500' => ! $dark]); ?>">estados + DF atendidos</p>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['rounded-2xl p-4', 'bg-white/[0.06] border border-white/10' => $dark, 'card' => ! $dark]); ?>">
                    <p class="font-display text-2xl font-bold text-gold-400"><?php echo e(br_number($map['abroad'])); ?></p>
                    <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-1 text-[11px] leading-tight', 'text-brand-200' => $dark, 'text-slate-500' => ! $dark]); ?>">clientes no exterior</p>
                </div>
            </div>

            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['rounded-2xl p-5', 'bg-white/[0.04] border border-white/10' => $dark, 'card' => ! $dark]); ?>">
                <p class="mb-4 text-xs font-semibold uppercase tracking-[0.16em] text-gold-400">Estados com mais clientes</p>
                <ul class="space-y-2.5">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $top; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li @mouseenter="hovered = { code: '<?php echo e($row->code); ?>', name: <?php echo \Illuminate\Support\Js::from($row->name)->toHtml() ?>, count: <?php echo e($row->client_count); ?> }" @mouseleave="hovered = null" class="cursor-default">
                            <div class="mb-1 flex items-center justify-between text-sm">
                                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-medium', 'text-white' => $dark, 'text-brand-900' => ! $dark]); ?>">
                                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mr-2 inline-block w-7 text-xs font-bold', 'text-brand-300' => $dark, 'text-brand-500' => ! $dark]); ?>"><?php echo e($row->code); ?></span><?php echo e($row->name); ?>

                                </span>
                                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['tabular-nums', 'text-brand-100' => $dark, 'text-slate-600' => ! $dark]); ?>"><?php echo e(br_number($row->client_count)); ?></span>
                            </div>
                            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['h-1.5 overflow-hidden rounded-full', 'bg-white/10' => $dark, 'bg-slate-100' => ! $dark]); ?>">
                                <div class="h-full rounded-full bg-gradient-to-r from-brand-400 to-gold-400" style="width: <?php echo e(max(3, round($row->client_count / $max * 100))); ?>%"></div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            </div>

            <div class="grid grid-cols-5 gap-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $map['regions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['rounded-xl px-2 py-3 text-center', 'bg-white/[0.04] border border-white/10' => $dark, 'bg-brand-50' => ! $dark]); ?>">
                        <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['font-display text-base font-bold', 'text-white' => $dark, 'text-brand-900' => ! $dark]); ?>"><?php echo e(br_number($region['count'])); ?></p>
                        <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-0.5 text-[10px] leading-tight', 'text-brand-300' => $dark, 'text-slate-500' => ! $dark]); ?>"><?php echo e($region['name']); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /home/claude/pkg/tinsei_site/resources/views/components/brazil-map.blade.php ENDPATH**/ ?>