<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'color']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'color']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<img
    src="<?php echo e(asset($variant === 'white' ? 'images/brand/logo-tinsei-white.png' : 'images/brand/logo-tinsei-color.png')); ?>"
    alt="Tinsei"
    width="198"
    height="93"
    <?php echo e($attributes->merge(['class' => 'h-10 w-auto select-none'])); ?>

>
<?php /**PATH /home/claude/pkg/tinsei_site/resources/views/components/logo.blade.php ENDPATH**/ ?>